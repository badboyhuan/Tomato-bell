#ifndef   _ADC_H
#define   _ADC_H
#include "air32f10x.h"

#define CONV_CHANNEL_NUM 2
#define VREF (3300) //����3000mV
extern uint32_t usb_v,bat_v;
extern uint8_t ADC_CovChannel[CONV_CHANNEL_NUM];
extern uint8_t ADC_SampleTIME[CONV_CHANNEL_NUM];
extern uint32_t DAM_ADC_Value[CONV_CHANNEL_NUM];

void ADC_init(void);

#endif

