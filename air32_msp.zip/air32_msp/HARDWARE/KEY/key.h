#ifndef _KEY__H
#define _KEY__H

#include <air32f10x.h>
#define KEY0  	GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)//��ȡ����0
#define KEY1   	GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)
#define KEY2   	GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)


#define KEY0_PRES 	1	//KEY0����
#define KEY1_PRES   2	
#define KEY2_PRES   3	

void KEY_Init(void);
u8 KEY_Scan(u8 mode);

#endif


