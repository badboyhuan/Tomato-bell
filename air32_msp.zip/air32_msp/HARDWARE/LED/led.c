#include "air32f10x.h"
#include "led.h"
void LED_Init(void)
{
	
	
  GPIO_InitTypeDef GPIO_InitStruct;//定义GPIO结构体变量
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOB,ENABLE);//使能GPIO C B口时钟 
  GPIO_InitStruct.GPIO_Pin=GPIO_Pin_13 ;//设置13 IO口
  GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;//设置为推挽输出
  GPIO_InitStruct.GPIO_Speed=GPIO_Speed_10MHz;
  GPIO_Init(GPIOC,&GPIO_InitStruct);//初始化函数  
	
  GPIO_InitStruct.GPIO_Pin=GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_2 ;
  GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;//设置为推挽输出
  GPIO_InitStruct.GPIO_Speed=GPIO_Speed_10MHz;
  GPIO_Init(GPIOB,&GPIO_InitStruct);//初始化函数  	
	
	
	
  GPIO_ResetBits(GPIOC,GPIO_Pin_13); //高电平
	GPIO_ResetBits(GPIOB,GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_2); //高电平
	
	
	
	
}
