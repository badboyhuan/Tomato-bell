#ifndef _LED__H
#define _LED__H

#define LED_OFF     GPIO_SetBits(GPIOC,GPIO_Pin_13)  //�ߵ�ƽ
#define LED_ON 	    GPIO_ResetBits(GPIOC,GPIO_Pin_13) //�͵�ƽ

#define LED_OUT_OFF  GPIO_SetBits(GPIOB,GPIO_Pin_11)  //�ߵ�ƽ
#define LED_OUT_ON  	GPIO_ResetBits(GPIOB,GPIO_Pin_11) //�͵�ƽ

#define LED_CC_OFF  GPIO_SetBits(GPIOB,GPIO_Pin_2)  //�ߵ�ƽ
#define LED_CC_ON 	GPIO_ResetBits(GPIOB,GPIO_Pin_2) //�͵�ƽ

#define LED_CV_OFF  GPIO_SetBits(GPIOB,GPIO_Pin_10)  //�ߵ�ƽ
#define LED_CV_ON 	GPIO_ResetBits(GPIOB,GPIO_Pin_10) //�͵�ƽ
void LED_Init(void);

#endif
