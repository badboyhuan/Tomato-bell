#include "menu.h"   
#include "oled.h"   
#include "bmp.h"
#include "adc.h" 
#include "wkup.h"
extern u8  Image_BW[5000];
key_table table[20]=
{
	//第0层
	{0,2,3,1,(*fun_0)},
  //第1层
	{1,2,3,12,(*fun_a1)},
	{2,2,3,4,(*fun_b1)},
	{3,2,3,9,(*fun_c1)},		
  //第2层
	{4,4,5,0,(*fun_b21)},					
	{5,4,6,0,(*fun_b22)},			
	{6,5,7,0,(*fun_b23)},	
	{7,6,8,0,(*fun_b24)},	
	{8,7,8,0,(*fun_b25)},	
	
	{9,10,11,0,(*fun_c21)},					
	{10,10,10,9,(*fun_c22)},				                	
	{11,11,11,9,(*fun_c23)},		

	{12,0,0,0,(*fun_03)},	
};

/*********第1层***********/
void fun_a1()   
{	
	OLED_Clear(WHITE);
	
	OLED_ShowString(70,16,(u8*)"It is up(Photo)",16,BLACK);
	OLED_ShowString(56,80,(u8*)"It is dowm(Clock)",16,BLACK);
	OLED_ShowString(10,115,(u8*)"It is Enter(blank)",16,BLACK);
	
	OLED_GUIInit(EPD_1IN54_PART);
	OLED_Display(Image_BW);
	EPD_Sleep();
	
}

void fun_b1()   
{	
	OLED_Clear(WHITE);
	OLED_ShowChinese(36,50,0,64,BLACK);
	OLED_ShowChinese(100,50,1,64,BLACK);
	OLED_DrawRectangle(1,1,200,200,BLACK,0);
	OLED_ShowString(191,183,(u8*)"1",16,BLACK);//页码
	OLED_GUIInit(EPD_1IN54_PART);
	OLED_Display(Image_BW);
	EPD_Sleep(); 											
}

void fun_c1()     
{	
	OLED_Clear(WHITE);
	OLED_ShowChinese(2,50,2,64,BLACK);
	OLED_ShowChinese(66,50,3,64,BLACK);
	OLED_ShowChinese(130,50,4,64,BLACK);
	OLED_DrawRectangle(1,1,200,200,BLACK,0);
	OLED_ShowString(191,183,(u8*)"2",16,BLACK);//页码
	OLED_GUIInit(EPD_1IN54_PART);
	OLED_Display(Image_BW);
	EPD_Sleep();
																					
}

void fun_03()     
{	
	
	OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_Display(Image_BW);
	EPD_Sleep();
	Sys_Enter_Standby();
}



/*********第2层***********/
void fun_b21()     
{	
	OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
//	OLED_Clear(WHITE);
	OLED_ShowPicture(0,0,200,200,gImage_guet,BLACK);
	OLED_DrawRectangle(13,150,43,180,BLACK,1);  //画矩形
	OLED_DrawRectangle(49,150,79,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(85,150,115,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(121,150,151,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(157,150,187,180,BLACK,0);  //画矩形
	OLED_Display(Image_BW);
	EPD_Sleep();
																					
}

void fun_b22()      
{	
	OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
	OLED_ShowPicture(0,0,200,200,gImage_1,BLACK);
	OLED_ShowString(0,8," Electronic pers",24,BLACK);//24 XXXXXXXXXXXX
	OLED_ShowString(0,30,"onal information",24,BLACK);
	OLED_ShowString(66,70,"Jiangxxxx",24,BLACK);//姓名
	OLED_ShowString(68,115,"13xxxxxxxxx",24,BLACK);//电话
	OLED_ShowString(80,174," Nanxxxx  ",24,BLACK);//市
	OLED_ShowString(90,151,"Guangxx",24,BLACK);//省
	OLED_DrawRectangle(13,150,43,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(49,150,79,180,BLACK,1);  //画矩形
	OLED_DrawRectangle(85,150,115,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(121,150,151,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(157,150,187,180,BLACK,0);  //画矩形
	OLED_Display(Image_BW);
	EPD_Sleep();
																							
}

void fun_b23()    
{
	OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowPicture(21,0,156,195,gImage_QQ,BLACK);
	OLED_DrawRectangle(13,150,43,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(49,150,79,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(85,150,115,180,BLACK,1);  //画矩形
	OLED_DrawRectangle(121,150,151,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(157,150,187,180,BLACK,0);  //画矩形
	OLED_Display(Image_BW);
	EPD_Sleep();																		
}

void fun_b24()    
{	
	OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowPicture(20,0,157,196,gImage_bilibili,BLACK);
	OLED_DrawRectangle(13,150,43,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(49,150,79,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(85,150,115,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(121,150,151,180,BLACK,1);  //画矩形
	OLED_DrawRectangle(157,150,187,180,BLACK,0);  //画矩形
	OLED_Display(Image_BW);
	EPD_Sleep();																		
}
void fun_b25()    
{	
	OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowPicture(0,0,200,200,gImage_like,BLACK);
	OLED_DrawRectangle(13,150,43,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(49,150,79,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(85,150,115,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(121,150,151,180,BLACK,0);  //画矩形
	OLED_DrawRectangle(157,150,187,180,BLACK,1);  //画矩形
	OLED_Display(Image_BW);
	EPD_Sleep();																					
}

void fun_c21()    
{	
	OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowString(70,16,(u8*)"It is up(25min)",16,BLACK);
	OLED_ShowString(56,80,(u8*)"It is dowm(5min)",16,BLACK);
	OLED_ShowString(10,115,(u8*)"It is Enter(blank)",16,BLACK);
	OLED_Display(Image_BW);
	EPD_Sleep();
																					
}

void fun_c22()    
{	
	OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowString(28,150,(u8*)"End is 25min",24,BLACK);
	OLED_Display(Image_BW);
	EPD_Sleep();																						
}

void fun_c23()    
{	
	OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowString(34,150,(u8*)"End is 5min",24,BLACK);
	OLED_Display(Image_BW);
	EPD_Sleep();																						
}
/*********第0层***********/
void fun_0()
{
	OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
	OLED_Clear(WHITE);
	OLED_ShowString(40,60,(u8*)"HELLO",48,BLACK);
	OLED_ShowString(35,140,(u8*)"Enter to Go",24,BLACK);
	OLED_DrawRectangle(30,139,170,165,BLACK,0);
	OLED_DrawRectangle(1,1,200,200,BLACK,0);
	OLED_Display(Image_BW);
	EPD_Sleep();

	
}
