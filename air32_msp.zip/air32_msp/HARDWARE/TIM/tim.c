#include "tim.h"
#include "freeRTOS_task.h"

u32 time = 0; 
u32 aa 	= 0; 

void TIM4_Init(u16 per, u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;   //定义定时器结构体变量
	NVIC_InitTypeDef NVIC_InitStruct;   //定义中断优先级结构体变量
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);   //使能TIM4的时钟
	
	TIM_TimeBaseInitStruct.TIM_Period=per;   //设置自动重装载的 周期值
	TIM_TimeBaseInitStruct.TIM_Prescaler=psc;   //设置预分频值
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;   //向上计数模式
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;   //设置 时钟分割
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStruct);   //定时器初始化函数
	
	/* TIM4 IRQ configuration */
	NVIC_InitStruct.NVIC_IRQChannel=TIM4_IRQn;   //TIM4中断通道
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=2;   //抢占优先级2
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=0;   //子优先级0
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;   //使能TIM4中断通道
	NVIC_Init(&NVIC_InitStruct);   //中断优先级初始化函数
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);   //TIM4中断使能
	TIM_Cmd(TIM4,ENABLE);   //TIM4使能
}

void TIM4_IRQHandler(void)   //TIM4中断服务函数
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)!=RESET)   //判断是否触发TIM4更新中断
	{
		TIM_ClearITPendingBit(TIM4,TIM_IT_Update);   //清除TIM4更新中断标志位
		if(aa<10)
		{
			aa++;
//			time++;
		}
		else 
		{
			aa = 0;
			time++;
		}
	}
}
