#include <stdio.h>
#include "freeRTOS_task.h"
#include "FreeRTOS.h"					//FreeRTOS使用
#include "task.h" 
#include "key.h"
#include "adc.h"
#include "oled.h"
#include "menu.h"
#include "control.h"
#include "tim.h"
#include "wkup.h"

void (*current_operation_index)();
u8 func_index = 0; //初始显示欢迎界面
u8 last_index = 127; //last初始为无效值
u8  Image_BW[5000];
/* 
此任务用于显示
*/
void myDisplayTask(void * pvParameters)
{
	char str_time[20];
	u32 time_last=0;
	for(;;)
	{
		ADC_SoftwareStartConvCmd(ADC1, ENABLE); //开始转换
		vTaskDelay(50);
		if (func_index != last_index)
		{
			time = 0;
			current_operation_index = table[func_index].current_operation;
			last_index = func_index;
			
			(*current_operation_index)();//执行当前操作函数
		}
		if(time_last!=time)
		{
			time_last=time;
			switch(last_index)
			{
				case 0://开始界面
						if(time_last>5)
						{
							OLED_Clear(WHITE);
							//No operation
							OLED_ShowString(50,92,"No operation",16,BLACK);//页码
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Display(Image_BW);
							EPD_Sleep();
							time = 0;
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
						else
						{
							sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
							OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
							sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
							OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
							
							OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
							OLED_Display(Image_BW);
							EPD_Sleep();
							break;
						}
				case 1://开始界面
						if(time_last>20)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Clear(WHITE);
							//No operation
							OLED_ShowString(50,92,"No operation",16,BLACK);//页码
							OLED_Display(Image_BW);
							EPD_Sleep();
							time = 0;
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
						else
					{
						sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
						OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
						sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
						OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
						
						OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
						OLED_Display(Image_BW);
						EPD_Sleep();
						break;
					}
				case 2:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Clear(WHITE);
							//No operation
							OLED_ShowString(50,92,"No operation",16,BLACK);//页码
							OLED_Display(Image_BW);
							EPD_Sleep();
							time = 0;
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
						else
						{
							sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
							OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
							sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
							OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
							
							OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
							OLED_Display(Image_BW);
							EPD_Sleep();
							break;
						}
				case 3:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Clear(WHITE);
							//No operation
							OLED_ShowString(50,92,"No operation",16,BLACK);//页码
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
						else
							{
								sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
								OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
								sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
								OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
								
								OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
								OLED_Display(Image_BW);
								EPD_Sleep();
								break;
							}
				case 4:
						if(time_last>10)
						{
							
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_ShowPicture(0,0,200,200,gImage_guet,BLACK);
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
					break;
				case 5:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
	//						OLED_Clear(WHITE);
							OLED_ShowPicture(0,0,200,200,gImage_1,BLACK);
							OLED_ShowString(0,8," Electronic pers",24,BLACK);//24 XXXXXXXXXXXX
							OLED_ShowString(0,30,"onal information",24,BLACK);
								OLED_ShowString(66,70,"Jiangxxxxxxx",24,BLACK);//姓名
							OLED_ShowString(68,115,"133xxxxxxxx",24,BLACK);//电话
							OLED_ShowString(80,174," Nanxxxx  ",24,BLACK);//市
							OLED_ShowString(90,151,"Guangxx",24,BLACK);//省
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
					break;
			case 6:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Clear(WHITE);
							OLED_ShowPicture(21,0,156,195,gImage_QQ,BLACK);
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
					break;
				case 7:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Clear(WHITE);
							OLED_ShowPicture(20,0,157,196,gImage_bilibili,BLACK);
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
					break;
				case 8:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_ShowPicture(0,0,200,200,gImage_like,BLACK);
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
						else
						{
							sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
							OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
							sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
							OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
							
							OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
							OLED_Display(Image_BW);
							EPD_Sleep();
						}
					break;
				case 9:
						if(time_last>10)
						{
							OLED_GUIInit(EPD_1IN54_FULL);//初始化电子墨水屏
							OLED_Clear(WHITE);
							OLED_Display(Image_BW);
							EPD_Sleep();
							Sys_Enter_Standby();	//系统进入待机模式
							break;
						}
						else
						{
							sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
							OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
							sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
							OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
							
							OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
							OLED_Display(Image_BW);
							EPD_Sleep();
							break;
						}
				case 10:
						if(time_last>1500)
						{
							func_index = 9;
							break;
						}
						sprintf(str_time,"%02d:%02d ",time_last/60,time_last%60);
						OLED_ShowString(20,50,(u8 *)str_time,64,BLACK);//时间
						
						sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
						OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
						sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
						OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
						
						OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
						OLED_Display(Image_BW);
						EPD_Sleep();
					break;
				case 11:
						if(time_last>300)
						{
							func_index = 9;
							break;
						}
						sprintf(str_time,"%02d:%02d",time_last/60,time_last%60);
						OLED_ShowString(20,50,(u8 *)str_time,64,BLACK);//时间
						
						sprintf(str_time,"In:%0.2fV",usb_v*6.6/4096);
						OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
						sprintf(str_time,"Bar:%0.2fV",bat_v*6.6/4096);
						OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
						
						OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
						OLED_Display(Image_BW);
						EPD_Sleep();
					break;
			}
//				sprintf(str_time,"C:%0.2fV",usb_v*6.6/4096);
//				OLED_ShowString(1,1,(u8 *)str_time,16,BLACK);//ty-C 电压
//				sprintf(str_time,"B:%0.2fV",bat_v*6.6/4096);
//				OLED_ShowString(100,1,(u8 *)str_time,16,BLACK);//bar 电压
//				OLED_GUIInit(EPD_1IN54_PART);//初始化电子墨水屏
//				OLED_Display(Image_BW);
//				EPD_Sleep();
		}
		vTaskDelay(100);
	}
}

/* 
此任务用于输入
*/
void myInputTask(void * pvParameters)
{
	u8 key = 0;
	for(;;)
	{
		key = KEY_Scan(0);
		if(key==KEY2_PRES)
		{
			func_index = table[func_index].up;
		}
		else if(key==KEY0_PRES)
			func_index = table[func_index].enter;  
		else if(key==KEY1_PRES)
			func_index = table[func_index].down;
			vTaskDelay(100);
	}
}
void FreeRTOS_Task_Config(void)
{
	taskENTER_CRITICAL();//进入临界值
	
	xTaskCreate(myDisplayTask, "MYDISPLAYTASK", 128, NULL, 1, NULL);//动态创建任务
	xTaskCreate(myInputTask, "MYINPUTTASK", 128, NULL, 2, NULL);//动态创建任务
	
//	pps = xPortGetFreeHeapSize();
	taskEXIT_CRITICAL();     //退出临界值
	/* Start scheduler */
	vTaskStartScheduler(); //开始
}

