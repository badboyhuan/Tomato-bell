#ifndef	__FREERTOS_TASK_H
#define	__FREERTOS_TASK_H

#include "air32f10x.h"
extern u8  Image_BW[5000];

void myDisplayTask(void * pvParameters);
void FreeRTOS_Task_Config(void);
	
void myControl(void);			//PID���PWM

#endif
