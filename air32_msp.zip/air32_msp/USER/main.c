#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#include "air32f10x.h"
#include "delay.h"
#include "air_rcc.h"
#include "tim.h"
#include "key.h"
#include "adc.h"
#include "control.h"
#include "freeRTOS_task.h"
#include "FreeRTOS.H"
#include "task.h"
#include "oled.h"
#include "wkup.h"
void RCC_ClkConfiguration(void);

void TIM_Configuration(uint16_t per, uint16_t psc);
int main(void)
{
	/**************初始化函数开始*******************/
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);//中断分组
	RCC_ClkConfiguration();				//配置时钟
	delay_init();									//延时初始化
	delay_xms(200);
	KEY_Init();										//按键初始化
	TIM4_Init(15999,999);					//16 000 000/1600/1000 = 10HZ = 1/10S
//	LED_Init();
	ADC_init(); 									//初始化ADC			   
	OLED_GPIOInit();							//初始化SPI 
	Paint_NewImage(Image_BW,OLED_W,OLED_H,0,WHITE); //设置新页 软件层面
	FreeRTOS_Task_Config();				//FreeRTOS初始化
	/**************初始化函数结束*******************/ 	 
	for(;;)
	{
		
	}
}
/**************初始化时钟*******************/ 
void RCC_ClkConfiguration(void)
{
	RCC_DeInit(); //复位RCC寄存器

	RCC_HSEConfig(RCC_HSE_ON); //使能HSE
	while (RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET)
		; //等待HSE就绪

	RCC_PLLCmd(DISABLE);										 //关闭PLL
	AIR_RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_2, 1); //配置PLL,8*27=216MHz

	RCC_PLLCmd(ENABLE); //使能PLL
	while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		; //等待PLL就绪

	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK); //选择PLL作为系统时钟

	RCC_HCLKConfig(RCC_SYSCLK_Div1); //配置AHB时钟
	RCC_PCLK1Config(RCC_HCLK_Div2);	 //配置APB1时钟
	RCC_PCLK2Config(RCC_HCLK_Div1);	 //配置APB2时钟

	RCC_LSICmd(ENABLE); //使能内部低速时钟
	while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET)
		;				//等待LSI就绪
	RCC_HSICmd(ENABLE); //使能内部高速时钟
	while (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET)
		; //等待HSI就绪
}
